# Research Notebook
By Essy Udeme · Tools & Templates

Three CSV files for keeping questions, sources and findings together. Use them in Notion or a spreadsheet. The example rows are invented and labelled Example; they are not research findings. Delete them after checking the setup.

## Start in Notion
1. Unzip this folder. In Notion, choose Settings > Import > CSV and select questions.csv. Repeat for sources.csv and findings.csv. Each import creates a separate database.
2. Check that the headers became properties. Keep IDs as text; set source date as a date and URL as a URL if needed. The first column is the row title. Other property types can be changed after import.
3. Open the example question Q-EXAMPLE, source S-EXAMPLE and finding F-EXAMPLE. Notice how the IDs connect the question and source to the finding. These are plain text references; CSV import does not create Notion relations or formulas.
4. Delete the example rows. Add your first question and the decision it informs. Use stable IDs such as Q-001, S-001 and F-001 in your own rows. Add a source before recording the finding.

Official CSV import instructions: https://www.notion.com/help/import-data-into-notion

## Start in a spreadsheet
Open each CSV using UTF-8. Keep the three files as sheets or tables. Make sure the IDs remain text. Use a semicolon between several source IDs in the findings file. Do not erase an ID while another row refers to it.

## Fields
questions.csv: Title, Question ID, Decision, Scope, Owner, Status, Stopping point.
sources.csv: Title, Source ID, URL, Date, Type, Notes, Limits.
findings.csv: Title, Finding ID, Question ID, Source IDs, Observation, Interpretation, Other explanation, Next check, Status.

## Working notes
An observation records what you heard, read or saw. An interpretation records what you think it means. Keep the original words and the source ID when quoting someone. Store participant details only with permission. Put sensitive notes in an appropriately restricted location.

Keep observations that disagree with your current idea. Record what the source cannot tell you. Review each finding before using it to decide what to make.

You can adapt these files for your own work. Please credit Essy Udeme if you redistribute them.
